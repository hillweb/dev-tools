// 直接加载官方完整版 SVGO 浏览器模块
import { optimize, VERSION } from './svgo.browser.js';
/**
 * 将单个 SVG path 的 d 字符串全部转换为绝对坐标（大写指令）
 */
function pathToAbsolute(d) {
    const tokens = d.match(/[a-zA-Z]|[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g);
    if (!tokens) return d;

    let i = 0;
    let cmd = '';
    let x = 0, y = 0;       // 当前点绝对坐标
    let startX = 0, startY = 0; // 当前子路径起点（用于 Z 闭合）
    const out = [];

    const nextNum = () => parseFloat(tokens[i++]);
    const fmt = (n) => Number(n.toFixed(4)); // 防止浮点精度漂移，后续 SVGO 会再按 floatPrecision 截断

    while (i < tokens.length) {
        if (/^[a-zA-Z]$/.test(tokens[i])) {
            cmd = tokens[i++];
        } else {
            // 处理省略指令符的隐式重复坐标（M 后的隐式坐标按 L/l 处理）
            if (cmd === 'M') cmd = 'L';
            else if (cmd === 'm') cmd = 'l';
        }

        const isRel = cmd === cmd.toLowerCase();
        const upper = cmd.toUpperCase();

        switch (upper) {
            case 'M': {
                const nx = nextNum() + (isRel ? x : 0);
                const ny = nextNum() + (isRel ? y : 0);
                x = startX = nx;
                y = startY = ny;
                out.push(`M${fmt(x)} ${fmt(y)}`);
                break;
            }
            case 'L': {
                const nx = nextNum() + (isRel ? x : 0);
                const ny = nextNum() + (isRel ? y : 0);
                x = nx; y = ny;
                out.push(`L${fmt(x)} ${fmt(y)}`);
                break;
            }
            case 'H': {
                const nx = nextNum() + (isRel ? x : 0);
                x = nx;
                // out.push(`H${fmt(x)}`);
                out.push(`L${fmt(x)} ${fmt(y)}`);
                break;
            }
            case 'V': {
                const ny = nextNum() + (isRel ? y : 0);
                y = ny;
                // out.push(`V${fmt(y)}`);
                out.push(`L${fmt(x)} ${fmt(y)}`);
                break;
            }
            case 'C': {
                const x1 = nextNum() + (isRel ? x : 0);
                const y1 = nextNum() + (isRel ? y : 0);
                const x2 = nextNum() + (isRel ? x : 0);
                const y2 = nextNum() + (isRel ? y : 0);
                const nx = nextNum() + (isRel ? x : 0);
                const ny = nextNum() + (isRel ? y : 0);
                x = nx; y = ny;
                out.push(`C${fmt(x1)} ${fmt(y1)} ${fmt(x2)} ${fmt(y2)} ${fmt(x)} ${fmt(y)}`);
                break;
            }
            case 'S': {
                const x2 = nextNum() + (isRel ? x : 0);
                const y2 = nextNum() + (isRel ? y : 0);
                const nx = nextNum() + (isRel ? x : 0);
                const ny = nextNum() + (isRel ? y : 0);
                x = nx; y = ny;
                out.push(`S${fmt(x2)} ${fmt(y2)} ${fmt(x)} ${fmt(y)}`);
                break;
            }
            case 'Q': {
                const x1 = nextNum() + (isRel ? x : 0);
                const y1 = nextNum() + (isRel ? y : 0);
                const nx = nextNum() + (isRel ? x : 0);
                const ny = nextNum() + (isRel ? y : 0);
                x = nx; y = ny;
                out.push(`Q${fmt(x1)} ${fmt(y1)} ${fmt(x)} ${fmt(y)}`);
                break;
            }
            case 'T': {
                const nx = nextNum() + (isRel ? x : 0);
                const ny = nextNum() + (isRel ? y : 0);
                x = nx; y = ny;
                out.push(`T${fmt(x)} ${fmt(y)}`);
                break;
            }
            case 'A': {
                const rx = nextNum();
                const ry = nextNum();
                const rot = nextNum();
                const largeArc = nextNum();
                const sweep = nextNum();
                const nx = nextNum() + (isRel ? x : 0);
                const ny = nextNum() + (isRel ? y : 0);
                x = nx; y = ny;
                out.push(`A${fmt(rx)} ${fmt(ry)} ${fmt(rot)} ${largeArc} ${sweep} ${fmt(x)} ${fmt(y)}`);
                break;
            }
            case 'Z': {
                x = startX;
                y = startY;
                out.push('Z');
                break;
            }
        }
    }

    return out.join('');
}

// 自定义 SVGO 插件：在所有优化完成后，将 path 强制转为绝对坐标
const forceAbsolutePathPlugin = {
    name: 'forceAbsolutePath',
    fn: () => ({
        element: {
            enter: (node) => {
                if (node.name === 'path' && node.attributes.d) {
                    node.attributes.d = pathToAbsolute(node.attributes.d);
                }
            },
        },
    }),
};
const cleanPathUselessAttrs = {
    name: 'cleanPathUselessAttrs',
    fn: () => ({
        element: {
            enter: (node) => {
                if (node.name !== 'path') return;

                for (const attrName of Object.keys(node.attributes)) {
                    if (
                        attrName.startsWith('font') ||
                        attrName.startsWith('paint') ||
                        attrName === 'letter-spacing' ||
                        attrName === 'word-spacing' ||
                        attrName === 'text-anchor'
                    ) {
                        delete node.attributes[attrName];
                    }
                }
            },
        },
    }),
};

const statusEl = document.getElementById('engineStatus');
statusEl.innerHTML = `SVGO v${VERSION} 引擎就绪`;
statusEl.innerHTML += '<a href="https://github.com/svg/svgo" target="_blank"><img width="20" src="github.svg"></img></a>';
statusEl.classList.add('ready');

const inputCode = document.getElementById('inputCode');
const outputCode = document.getElementById('outputCode');
const previewBox = document.getElementById('previewBox');
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');

let currentTab = 'code';
let uploadedFiles = [];

function runSvgo(rawSvg) {
    if (!rawSvg || !rawSvg.trim()) return '';
    const floatPrecision = Number(document.getElementById('optPrecision').value);
    const multipass = document.getElementById('optMultipass').checked;
    const mergePaths = document.getElementById('optMergePaths').checked;
    const removeFill = document.getElementById('optRemoveFill').checked;
    const removeStyle = document.getElementById('optRemoveStyle').checked;
    const absolutePath = document.getElementById('optAbsolutePath').checked;
    const shapToPath = document.getElementById('optShapToPath').checked;
    const cleanIds = document.getElementById('optClenIds').checked;
    //optShapToPath
    const plugins = [
        {
            name: 'preset-default',
            params: {
                overrides: {
                    cleanupNumericValues: { floatPrecision },
                    convertPathData: {
                        floatPrecision,
                        smartCollapse: false,
                        lineShorthands: true,
                    },
                    convertTransform: { floatPrecision },
                    mergePaths: mergePaths ? { force: true, floatPrecision } : false,
                    inlineStyles: { onlyMatchedOnce: false },
                    //转换形状为路径
                    convertShapeToPath: shapToPath ? {
                        floatPrecision,
                        convertArcs: true,
                        convertEllipses: true,
                        convertCircles: true,
                        convertLines: true,
                        convertRects: true,
                    } : false,
                    cleanupIds: cleanIds,

                }
            }
        },

        // 将 width/height 转为 viewBox 进一步精简
        'removeDimensions',
        'convertStyleToAttrs',
        'collapseGroups',
        'moveGroupAttrsToElems',
        // 'moveElemsAttrsToGroup',
        'removeStyleElement',
        cleanPathUselessAttrs,
    ];

    if (removeFill) {
        plugins.push({
            name: 'removeAttrs',
            params: { attrs: 'fill' }
        });
    }
    if (removeStyle) {
        plugins.push({
            name: 'removeAttrs',
            params: { attrs: 'style' }
        });
    }

    if (absolutePath) {
        plugins.push(forceAbsolutePathPlugin);
    }

    try {
        const result = optimize(rawSvg, { multipass, plugins });
        return result.data;
    } catch (err) {
        return `/* SVG 解析失败: ${err.message} */`;
    }
}

function buildSprites(files) {
    const symbols = files.map((file, idx) => {
        const optimized = runSvgo(file.content);
        const doc = new DOMParser().parseFromString(optimized, 'image/svg+xml');
        const svg = doc.querySelector('svg');
        if (!svg) return '';
        const id = file.name.replace(/\.svg$/i, '') || `icon-${idx}`;
        const viewBox = svg.getAttribute('viewBox') || '0 0 24 24';
        return `<symbol id="${id}" viewBox="${viewBox}">${svg.innerHTML}</symbol>`;
    }).join('');
    return `<svg xmlns="http://www.w3.org/2000/svg" style="display:none">${symbols}</svg>`;
}

function svgToCssUrl(svg) {
    const encoded = svg
        .replace(/"/g, "'")
        .replace(/%/g, '%25')
        .replace(/#/g, '%23')
        .replace(/{/g, '%7B')
        .replace(/}/g, '%7D')
        .replace(/</g, '%3C')
        .replace(/>/g, '%3E');
    return `url("data:image/svg+xml,${encoded}")`;
}

function process() {
    const isSprite = document.getElementById('optMergeSprite').checked && uploadedFiles.length > 0;
    const raw = inputCode.value;
    const compressed = isSprite ? buildSprites(uploadedFiles) : runSvgo(raw);

    const origBytes = new Blob([raw]).size;
    const compBytes = new Blob([compressed]).size;
    const saved = origBytes - compBytes;
    const ratio = origBytes > 0 ? ((saved / origBytes) * 100).toFixed(1) : 0;

    //字节转为K字节
    const origBytesK = (origBytes / 1024).toFixed(1);
    const compBytesK = (compBytes / 1024).toFixed(1);
    const savedK = (saved / 1024).toFixed(1);

    document.getElementById('origSize').textContent = `原始大小: ${origBytesK} KB`;
    document.getElementById('compSize').innerHTML = origBytes > 0
        ? `压缩后: ${compBytesK} KB <span class="highlight">(节省 ${savedK} KB / ${ratio}%)</span>`
        : `压缩后: 0 B`;

    if (currentTab === 'preview') {
        outputCode.classList.add('hidden');
        previewBox.classList.remove('hidden');
        previewBox.innerHTML = compressed;
    } else {
        previewBox.classList.add('hidden');
        outputCode.classList.remove('hidden');
        if (currentTab === 'code') {
            outputCode.value = compressed;
        } else if (currentTab === 'base64') {
            outputCode.value = compressed ? `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(compressed)))}` : '';
        } else if (currentTab === 'css') {
            outputCode.value = compressed ? svgToCssUrl(compressed) : '';
        }
    }

    //=================获取svg的宽高
    // let extractedSize = getSvgContentBBox(compressed);
    // console.log(extractedSize);
}

// 事件监听
inputCode.addEventListener('input', () => { uploadedFiles = []; process(); });
document.querySelectorAll('.options input, .options select').forEach(el => el.addEventListener('change', process));

document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentTab = btn.dataset.tab;
        process();
    });
});

// dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('dragover'); });
// dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
// dropZone.addEventListener('drop', e => {
//     e.preventDefault();
//     dropZone.classList.remove('dragover');
//     handleFiles(e.dataTransfer.files);
// });
const workspace = document.querySelector('.container');
workspace.addEventListener('dragover', e => {
    e.preventDefault(); dropZone.classList.add('dragover');
});
workspace.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
workspace.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    handleFiles(e.dataTransfer.files);
});


dropZone.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', e => handleFiles(e.target.files));

async function handleFiles(fileList) {
    const svgFiles = Array.from(fileList).filter(f => f.name.endsWith('.svg'));
    if (!svgFiles.length) return;
    uploadedFiles = await Promise.all(svgFiles.map(async f => ({
        name: f.name,
        content: await f.text()
    })));
    dropZone.innerHTML = uploadedFiles.map(f => f.name).join(', ');
    inputCode.value = uploadedFiles.map(f => f.content).join('\n\n');
    if (uploadedFiles.length > 1) {
        document.getElementById('optMergeSprite').checked = true;
    }
    process();
}

document.getElementById('copyBtn').addEventListener('click', () => {
    navigator.clipboard.writeText(outputCode.value);
    const btn = document.getElementById('copyBtn');
    btn.textContent = '已复制 ✓';
    setTimeout(() => btn.textContent = '复制结果', 1500);
});

document.getElementById('downloadBtn').addEventListener('click', () => {
    const content = currentTab === 'code' ? outputCode.value : runSvgo(inputCode.value);
    if (!content) return;
    const blob = new Blob([content], { type: 'image/svg+xml' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'optimized.svg';
    a.click();
});
//
document.getElementById('convertBtn').addEventListener('click', () => {
    const content = currentTab === 'code' ? outputCode.value : runSvgo(inputCode.value);
    if (!content) return;
    document.querySelector('[data-tab="preview"]').click()
});
//svg转png ； convertToPngBtn
document.getElementById('convertToPngBtn').addEventListener('click', () => {
    const content = currentTab === 'code' ? outputCode.value : runSvgo(inputCode.value);
    if (!content) return;
    exportSvgToRaster(content, 'png', 800);
});
//SVG转Jpg；convertToJpgBtn
document.getElementById('convertToJpgBtn').addEventListener('click', () => {
    const content = currentTab === 'code' ? outputCode.value : runSvgo(inputCode.value);
    if (!content) return;
    exportSvgToRaster(content, 'jpeg', 800);
});
//SVG转ICO；convertToIcoBtn
document.getElementById('convertToIcoBtn').addEventListener('click', () => {
    const content = currentTab === 'code' ? outputCode.value : runSvgo(inputCode.value);
    if (!content) return;
    exportSvgToRaster(content, 'ico', 256);
});
/**
 * 将 SVG 字符串转换为 PNG / JPG / ICO 并触发下载
 * @param {string} svgString - 原始或经过 SVGO 压缩的 SVG 代码
 * @param {'png'|'jpeg'|'ico'} format - 目标格式
 * @param {number} size - 目标尺寸（宽高，如 32, 64, 256, 512）
 */
function isStrictNumber(value) {
    return typeof value === 'number' && Number.isFinite(value);
}
async function exportSvgToRaster(svgString, format = 'png', size = null) {
    // 1. 确保 SVG 根节点带有明确的宽高，否则部分浏览器 Canvas 绘制时可能尺寸异常
    const parser = new DOMParser();
    const doc = parser.parseFromString(svgString, 'image/svg+xml');
    const svgEl = doc.querySelector('svg');
    if (!svgEl) throw new Error('无效的 SVG 代码');
    const svgsize = getSvgContentBBox(svgString);
    // size=svgsize;
    if (isStrictNumber(size)) {
        if (svgsize.width > svgsize.height) {
            size = { width: size, height: svgsize.height * size / svgsize.width }
        } else {
            size = { width: svgsize.width * size / svgsize.height, height: size }
        }
    } else {
        size = svgsize;
    }
    // size.height = size.height*2;

    svgEl.setAttribute('width', size.width);
    svgEl.setAttribute('height', size.height);
    const finalSvg = new XMLSerializer().serializeToString(svgEl);

    // 2. 创建 Blob 与 Image
    const svgBlob = new Blob([finalSvg], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);

    const img = new Image();
    await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
        img.src = url;
    });

    // 3. 绘制到 Canvas
    const canvas = document.createElement('canvas');
    canvas.width = size.width;
    canvas.height = size.height;
    const ctx = canvas.getContext('2d');

    // JPG 不支持透明，必须填充白色背景
    if (format === 'jpeg') {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, size.width, size.height);
    }

    ctx.drawImage(img, 0, 0, size.width, size.height);
    URL.revokeObjectURL(url);

    const canvas2=canvas.cloneNode(true);
    canvas2.width = size.width/2;
    canvas2.height = size.height/2;
    const ctx2 = canvas2.getContext('2d');
        ctx2.drawImage(img, 0, 0, size.width/2, size.height/2);
    URL.revokeObjectURL(url);

    // 4. 导出与下载
    if (format === 'ico') {
        // 限制 ICO 单个图像最大尺寸为 256x256（ICO 规范限制，256 在头信息中记为 0）
        const icoBlob = await multiCanvasToIcoBlob([canvas2,canvas]);
        // const icoBlob = await canvasToIcoBlob(canvas);
        triggerDownload(icoBlob, `icon-${size.width}x${size.height}.ico`);
    } else {
        const mimeType = format === 'jpeg' ? 'image/jpeg' : 'image/png';
        canvas.toBlob((blob) => {
            triggerDownload(blob, `image-${size.width}x${size.height}.${format === 'jpeg' ? 'jpg' : 'png'}`);
        }, mimeType, 0.92);
    }
}

/**
 * 将 Canvas 封装为标准 Windows ICO 格式 (内嵌 PNG 帧)
 */
async function canvasToIcoBlob(canvas) {
    const pngBlob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
    const pngBuffer = await pngBlob.arrayBuffer();
    const pngBytes = new Uint8Array(pngBuffer);

    // 6 字节 ICONDIR + 16 字节 ICONDIRENTRY = 22 字节文件头
    const header = new ArrayBuffer(22);
    const view = new DataView(header);

    // ICONDIR
    view.setUint16(0, 0, true); // 保留位，必须为 0
    view.setUint16(2, 1, true); // 类型：1 代表 ICO，2 代表 CUR
    view.setUint16(4, 1, true); // 包含的图像数量：1 张

    // ICONDIRENTRY
    const width = canvas.width >= 256 ? 0 : canvas.width;
    const height = canvas.height >= 256 ? 0 : canvas.height;
    view.setUint8(6, width);              // 宽度 (0 表示 256px)
    view.setUint8(7, height);             // 高度 (0 表示 256px)
    view.setUint8(8, 0);                  // 调色板颜色数 (PNG 填 0)
    view.setUint8(9, 0);                  // 保留位
    view.setUint16(10, 1, true);          // 色彩平面数
    view.setUint16(12, 32, true);         // 色深 (32位 RGBA)
    view.setUint32(14, pngBytes.length, true); // 图像数据大小（字节）
    view.setUint32(18, 22, true);         // 图像数据起始偏移量

    return new Blob([header, pngBytes], { type: 'image/x-icon' });
}
/**
 * 将多个 Canvas 封装为标准 Windows ICO 格式 (内嵌 PNG 帧)
 * @param {HTMLCanvasElement[]} canvases - Canvas 元素数组，建议按尺寸从小到大排列
 * @returns {Promise<Blob>} ICO 格式的 Blob 对象
 */
async function multiCanvasToIcoBlob(canvases) {
    if (!canvases || canvases.length === 0) {
        throw new Error("至少需要一个 Canvas");
    }

    // 1. 并行将所有 Canvas 转换为 PNG Uint8Array
    // 使用 Promise.all 提高性能，避免串行等待
    const pngDataList = await Promise.all(
        canvases.map(async (canvas) => {
            const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
            if (!blob) throw new Error("Canvas 转换 Blob 失败");
            const buffer = await blob.arrayBuffer();
            return {
                width: canvas.width,
                height: canvas.height,
                data: new Uint8Array(buffer)
            };
        })
    );

    // 2. 计算文件结构大小
    const imageCount = pngDataList.length;
    const headerSize = 6; // ICONDIR 固定 6 字节
    const entrySize = 16; // 每个 ICONDIRENTRY 固定 16 字节
    const directorySize = headerSize + (imageCount * entrySize);
    console.log(imageCount);
    
    // 计算总文件大小并预分配 ArrayBuffer
    let totalSize = directorySize;
    pngDataList.forEach(img => {
        totalSize += img.data.length;
    });

    const buffer = new ArrayBuffer(totalSize);
    const view = new DataView(buffer);
    let currentOffset = directorySize; // 当前写入数据的偏移量指针

    // 3. 写入 ICONDIR (文件头)
    view.setUint16(0, 0, true);       // idReserved: 必须为 0
    view.setUint16(2, 1, true);       // idType: 1 为 ICO, 2 为 CUR
    view.setUint16(4, imageCount, true); // idCount: 图像数量

    // 4. 写入 ICONDIRENTRY (目录项) 和 图像数据
    for (let i = 0; i < imageCount; i++) {
        const img = pngDataList[i];
        const entryOffset = headerSize + (i * entrySize);

        // --- 写入目录项 (16 bytes) ---
        
        // 宽度: 0 表示 256px, 其他表示实际像素
        view.setUint8(entryOffset + 0, img.width >= 256 ? 0 : img.width);
        
        // 高度: 0 表示 256px, 其他表示实际像素
        view.setUint8(entryOffset + 1, img.height >= 256 ? 0 : img.height);
        
        view.setUint8(entryOffset + 2, 0);      // bColorCount: 0 (PNG 无调色板)
        view.setUint8(entryOffset + 3, 0);      // bReserved: 保留位
        
        view.setUint16(entryOffset + 4, 1, true);  // wPlanes: 色彩平面数，固定 1
        view.setUint16(entryOffset + 6, 32, true); // wBitCount: 色深，PNG 通常为 32 (RGBA)
        
        view.setUint32(entryOffset + 8, img.data.length, true); // dwBytesInRes: 图像数据大小
        view.setUint32(entryOffset + 12, currentOffset, true);  // dwImageOffset: 数据起始偏移量

        // --- 写入图像数据 ---
        // 将 PNG 二进制数据复制到 Buffer 的指定偏移位置
        new Uint8Array(buffer, currentOffset).set(img.data);
        
        // 更新下一个图像的偏移量
        currentOffset += img.data.length;
    }

    // 5. 返回 Blob
    return new Blob([buffer], { type: 'image/x-icon' });
}


function triggerDownload(blob, filename) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}


/**
 * 获取 SVG 内容的实际几何包围盒（不受 CSS 缩放/transform 影响，返回用户坐标系的 x, y, width, height）
 * @param {string | SVGSVGElement} svgInput
 * @returns {{ x: number, y: number, width: number, height: number } | null}
 */
function getSvgContentBBox(svgInput) {
    const container = document.createElement('div');
    container.style.cssText =
        'position:fixed;left:-9999px;top:-9999px;visibility:hidden;pointer-events:none;';

    let svgEl;
    if (typeof svgInput === 'string') {
        container.innerHTML = svgInput;
        svgEl = container.querySelector('svg');
    } else if (svgInput instanceof SVGElement) {
        svgEl = svgInput.tagName.toLowerCase() === 'svg' ? svgInput.cloneNode(true) : svgInput.closest('svg');
        if (svgEl) container.appendChild(svgEl);
    }

    if (!svgEl) return null;

    document.body.appendChild(container);
    try {
        // 返回 DOMRect 对象：{ x, y, width, height }
        const { x, y, width: w, height: h } = svgEl.getBBox();
        //保留4位小数
        let width = parseFloat(w.toFixed(2));
        let height = parseFloat(h.toFixed(2));
        return { width, height };
    } catch (err) {
        // 例如空 SVG 或包含无法计算几何框的节点时可能抛错
        console.warn('getBBox 调用失败:', err);
        return null;
    } finally {
        container.remove();
    }
}