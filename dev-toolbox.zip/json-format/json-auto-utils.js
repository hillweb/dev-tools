/**
 * Shared JSON helpers for the auto-format content script.
 * This file is intentionally a classic script so chrome.scripting can inject it
 * before content-script.js without requiring module support.
 */
(function (root, factory) {
    const utils = factory();
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = utils;
    }
    root.FHJsonAutoUtils = utils;
})(typeof globalThis !== 'undefined' ? globalThis : window, function () {
    const PRESERVED_INTEGER_KEY_PREFIX = '__FH_PRESERVE_INTEGER_KEY__';

    function isBigNumberLike(value) {
        return (
            value !== null &&
            value !== undefined &&
            typeof value === 'object' &&
            typeof value.s === 'number' &&
            typeof value.e === 'number' &&
            Array.isArray(value.c)
        );
    }

    function rebuildBigNumberFromParts(value) {
        const sign = value.s < 0 ? '-' : '';
        const chunkSize = 14;
        let digits = '';

        for (let i = 0; i < value.c.length; i++) {
            let chunkStr = Math.abs(value.c[i]).toString();
            if (i > 0) {
                chunkStr = chunkStr.padStart(chunkSize, '0');
            }
            digits += chunkStr;
        }

        digits = digits.replace(/^0+/, '') || '0';
        const decimalIndex = value.e + 1;

        if (decimalIndex <= 0) {
            const zeros = '0'.repeat(Math.abs(decimalIndex));
            let fraction = zeros + digits;
            fraction = fraction.replace(/0+$/, '');
            return fraction ? sign + '0.' + fraction : sign + '0';
        }
        if (decimalIndex >= digits.length) {
            return sign + digits + '0'.repeat(decimalIndex - digits.length);
        }

        const intPart = digits.slice(0, decimalIndex);
        const fracPart = digits.slice(decimalIndex).replace(/0+$/, '');
        return fracPart ? sign + intPart + '.' + fracPart : sign + intPart;
    }

    function getBigNumberDisplayString(value) {
        if (typeof value === 'bigint') return value.toString();
        if (!isBigNumberLike(value)) return String(value);

        if (typeof value.toString === 'function' && value.toString !== Object.prototype.toString) {
            try {
                const result = value.toString();
                if (typeof result === 'string' && result !== '[object Object]') {
                    return result;
                }
            } catch (_) { }
        }
        return rebuildBigNumberFromParts(value);
    }

    function isInsideQuotedSegment(text, offset) {
        let quote = '';
        let escaped = false;

        for (let i = 0; i < offset; i++) {
            const char = text[i];
            if (escaped) {
                escaped = false;
                continue;
            }
            if (char === '\\') {
                escaped = true;
                continue;
            }
            if (quote) {
                if (char === quote) {
                    quote = '';
                }
                continue;
            }
            if (char === '"' || char === "'") {
                quote = char;
            }
        }

        return !!quote;
    }

    function replaceOutsideQuotedSegments(text, regex, replacer) {
        return text.replace(regex, function () {
            const args = Array.prototype.slice.call(arguments);
            const offset = args[args.length - 2];
            if (isInsideQuotedSegment(text, offset)) {
                return args[0];
            }
            return replacer.apply(null, args);
        });
    }

    function normalizeBooleanTokens(text) {
        // Match strings as whole tokens so escaped quotes and literal text stay intact.
        return text.replace(/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|[A-Za-z_$][\w$]*/g, token => {
            return /^(?:true|false)$/i.test(token) ? token.toLowerCase() : token;
        });
    }

    function normalizeLooseJSONSource(text) {
        let fixed = String(text).trim();

        fixed = replaceOutsideQuotedSegments(
            fixed,
            /([\{,]\s*)'([^'\\]*?)'(\s*:)/g,
            function (match, prefix, key, suffix) {
                return prefix + '"' + key + '"' + suffix;
            },
        );
        fixed = replaceOutsideQuotedSegments(
            fixed,
            /([\{,]\s*)(\w+)(\s*:)/g,
            function (match, prefix, key, suffix) {
                return prefix + '"' + key + '"' + suffix;
            },
        );
        fixed = replaceOutsideQuotedSegments(
            fixed,
            /(:\s*)'([^'\\]*?)'/g,
            function (match, prefix, value) {
                return prefix + '"' + value + '"';
            },
        );

        return normalizeBooleanTokens(fixed);
    }

    function isIntegerIndexKey(key) {
        if (typeof key !== 'string' || !/^(0|[1-9]\d*)$/.test(key)) return false;
        const value = Number(key);
        return Number.isSafeInteger(value) && value >= 0 && value < 4294967295 && String(value) === key;
    }

    function markIntegerIndexKeys(source) {
        source = String(source || '');
        let result = '';
        let i = 0;

        while (i < source.length) {
            if (source[i] !== '"') {
                result += source[i++];
                continue;
            }

            const start = i;
            i++;
            let escaped = false;
            while (i < source.length) {
                const char = source[i++];
                if (escaped) {
                    escaped = false;
                    continue;
                }
                if (char === '\\') {
                    escaped = true;
                    continue;
                }
                if (char === '"') {
                    break;
                }
            }

            const rawKey = source.slice(start, i);
            let j = i;
            while (j < source.length && /\s/.test(source[j])) j++;

            if (source[j] === ':') {
                try {
                    const key = JSON.parse(rawKey);
                    if (isIntegerIndexKey(key)) {
                        result += JSON.stringify(PRESERVED_INTEGER_KEY_PREFIX + key);
                        continue;
                    }
                } catch (_) { }
            }

            result += rawKey;
        }

        return result;
    }

    function normalizePreservedKey(key) {
        if (typeof key === 'string' && key.indexOf(PRESERVED_INTEGER_KEY_PREFIX) === 0) {
            return key.slice(PRESERVED_INTEGER_KEY_PREFIX.length);
        }
        return key;
    }

    function normalizePreservedJsonPointer(path) {
        if (typeof path !== 'string') return path;

        return path.split('/').map(function (segment, index) {
            if (index === 0) return segment;
            if (segment.indexOf(PRESERVED_INTEGER_KEY_PREFIX) === 0) {
                return segment.slice(PRESERVED_INTEGER_KEY_PREFIX.length);
            }
            return segment;
        }).join('/');
    }

    function parseStrictJSONWithBigInt(text) {
        const ordered = markIntegerIndexKeys(String(text || ''));

        const marked = ordered.replace(
            /([:,\[]\s*)(-?\d{16,})(\s*)(?=(?:,|\]|\}|$))/g,
            function (match, prefix, number, spaces, offset) {
                if (isInsideQuotedSegment(ordered, offset)) return match;
                return prefix + '"__BigInt__' + number + '"' + spaces;
            },
        );

        return JSON.parse(marked, function (_key, value) {
            if (typeof value === 'string' && value.startsWith('__BigInt__')) {
                try {
                    return BigInt(value.slice(10));
                } catch (_) {
                    return value.slice(10);
                }
            }
            return value;
        });
    }

    function parseWithBigInt(text) {
        return parseStrictJSONWithBigInt(normalizeLooseJSONSource(text));
    }

    function isJSONContainer(value) {
        if (typeof value !== 'object' || value === null) return false;
        if (!Array.isArray(value) && Object.prototype.toString.call(value) !== '[object Object]') return false;
        if (isBigNumberLike(value) && Object.keys(value).length === 3) return false;
        return true;
    }

    function deepParseJSONStrings(obj) {
        if (Array.isArray(obj)) {
            return obj.map((item) => {
                if (typeof item === 'string' && item.trim()) {
                    try {
                        const parsed = parseWithBigInt(item);
                        if (isJSONContainer(parsed)) {
                            return deepParseJSONStrings(parsed);
                        }
                    } catch (_) { }
                }
                return deepParseJSONStrings(item);
            });
        }
        if (typeof obj === 'object' && obj !== null) {
            const newObj = {};
            Object.keys(obj).forEach((key) => {
                const value = obj[key];
                if (typeof value === 'string' && value.trim()) {
                    try {
                        const parsed = parseWithBigInt(value);
                        if (isJSONContainer(parsed)) {
                            newObj[key] = deepParseJSONStrings(parsed);
                            return;
                        }
                    } catch (_) { }
                }
                newObj[key] = deepParseJSONStrings(value);
            });
            return newObj;
        }
        return obj;
    }

    function unpackTopLevelEscapedJSON(value) {
        if (typeof value !== 'string' || !value.trim()) return value;

        try {
            const parsed = parseWithBigInt(value);
            if (isJSONContainer(parsed)) {
                return deepParseJSONStrings(parsed);
            }
        } catch (_) { }

        return value;
    }

    function safeStringify(obj, space) {
        const tagged = JSON.stringify(
            obj,
            function (_key, value) {
                if (typeof value === 'bigint') {
                    return `__FH_BIGINT__${value.toString()}`;
                }
                if (typeof value === 'number' && value.toString().includes('e')) {
                    return `__FH_NUMSTR__${value.toLocaleString('fullwide', { useGrouping: false })}`;
                }
                if (isBigNumberLike(value)) {
                    return `__FH_BIGNUM__${getBigNumberDisplayString(value)}`;
                }
                return value;
            },
            space,
        );

        return tagged
            .replace(/"__FH_BIGINT__(-?\d+)"/g, '$1')
            .replace(/"__FH_NUMSTR__(-?\d+)"/g, '$1')
            .replace(/"__FH_BIGNUM__(-?\d+(?:\.\d+)?)"/g, '$1')
            .replace(new RegExp('"' + PRESERVED_INTEGER_KEY_PREFIX + '(\\d+)":', 'g'), '"$1":');
    }

    function unwrapJSONLikeSource(source, options) {
        options = options || {};
        source = String(source || '').trim();
        let fnTry = null;
        let fnCatch = null;
        let funcName = null;

        if (options.allowJSONP === false) {
            return { source, funcName, fnTry, fnCatch };
        }

        if (source.startsWith('try {')) {
            fnTry = 'try {';
            source = source.slice(5).trimStart();
        }

        const catchIdx = source.lastIndexOf('} catch');
        if (catchIdx !== -1) {
            fnCatch = source.slice(catchIdx);
            source = source.slice(0, catchIdx).trimEnd();
        }

        const matches = /^([\w\.]+)\(\s*([\s\S]*)\s*\)$/m.exec(source);
        if (matches != null && ((fnTry && fnCatch) || (!fnTry && !fnCatch))) {
            funcName = matches[1];
            source = matches[2];
        }

        return { source, funcName, fnTry, fnCatch };
    }

    function stripJSONGuards(source) {
        source = String(source || '').trim().replace(/^\uFEFF/, '');
        source = source
            .replace(/^\)\]\}',?\s*/, '')
            .replace(/^while\s*\(\s*1\s*\)\s*;\s*/, '')
            .replace(/^for\s*\(\s*;\s*;\s*\)\s*;\s*/, '');
        return source.trim();
    }

    function extractBalancedJSONContainer(source) {
        source = String(source || '');
        const start = source.search(/[\{\[]/);
        if (start < 0) return '';

        const stack = [];
        let quote = '';
        let escaped = false;

        for (let i = start; i < source.length; i++) {
            const char = source[i];

            if (quote) {
                if (escaped) {
                    escaped = false;
                    continue;
                }
                if (char === '\\') {
                    escaped = true;
                    continue;
                }
                if (char === quote) {
                    quote = '';
                }
                continue;
            }

            if (char === '"' || char === "'") {
                quote = char;
                continue;
            }

            if (char === '{' || char === '[') {
                stack.push(char);
                continue;
            }

            if (char === '}' || char === ']') {
                const expected = char === '}' ? '{' : '[';
                if (stack[stack.length - 1] !== expected) {
                    return '';
                }
                stack.pop();
                if (!stack.length) {
                    return source.slice(start, i + 1).trim();
                }
            }
        }

        return '';
    }

    function buildJSONLikeCandidates(source, options) {
        options = options || {};
        const candidates = [];
        const seen = new Set();
        const addCandidate = (value) => {
            value = String(value || '').trim();
            if (!value || seen.has(value)) return;
            seen.add(value);
            candidates.push(value);
        };

        const normalized = String(source || '').trim();
        const stripped = stripJSONGuards(normalized);

        addCandidate(normalized);
        addCandidate(stripped);

        if (options.allowExtractJSONFragment !== false && !/^[\{\[]/.test(stripped) && !(options.nestedEscapeParse && /^["']/.test(stripped))) {
            addCandidate(extractBalancedJSONContainer(stripped));
            addCandidate(extractBalancedJSONContainer(normalized));
        }

        return candidates;
    }

    function parseJSONLike(source, options) {
        options = options || {};
        const meta = unwrapJSONLikeSource(source, options);
        const candidates = buildJSONLikeCandidates(meta.source, options);

        for (let i = 0; i < candidates.length; i++) {
            const candidate = candidates[i];
            let jsonObj = null;
            const startsAsContainer = /^[\{\[]/.test(candidate);
            const startsAsEscapedContainer = options.nestedEscapeParse && /^["']/.test(candidate);

            if (!startsAsContainer && !startsAsEscapedContainer) {
                continue;
            }

            try {
                jsonObj = parseWithBigInt(candidate);
            } catch (_) {
                try {
                    jsonObj = new Function('return ' + candidate)();
                } catch (exx) {
                    try {
                        jsonObj = new Function("return '" + candidate + "'")();
                        if (typeof jsonObj === 'string') {
                            try {
                                jsonObj = parseWithBigInt(jsonObj);
                            } catch (_) {
                                jsonObj = new Function('return ' + jsonObj)();
                            }
                        }
                    } catch (_) {
                        continue;
                    }
                }
            }

            if (options.nestedEscapeParse && typeof jsonObj === 'string') {
                jsonObj = unpackTopLevelEscapedJSON(jsonObj);
            }
            if (options.nestedEscapeParse && isJSONContainer(jsonObj)) {
                jsonObj = deepParseJSONStrings(jsonObj);
            }
            if (!isJSONContainer(jsonObj)) {
                continue;
            }

            try {
                meta.source = candidate;
                meta.normalizedSource = safeStringify(jsonObj);
                meta.value = jsonObj;
                return meta;
            } catch (_) {
                return null;
            }
        }

        return null;
    }

    function getStandaloneHTMLJSONCandidate(signals, options) {
        signals = signals || {};
        const directText = String(signals.directText || '').trim();
        const preTexts = (signals.preTexts || [])
            .map((text) => String(text || '').trim())
            .filter(Boolean);
        const otherElementTexts = (signals.otherElementTexts || [])
            .map((text) => String(text || '').trim())
            .filter(Boolean);

        if (otherElementTexts.length) return false;

        let candidate = '';
        if (preTexts.length === 1 && !directText) {
            candidate = preTexts[0];
        } else if (preTexts.length === 0 && directText) {
            candidate = directText;
        } else {
            return false;
        }

        try {
            const parsed = parseStrictJSONWithBigInt(candidate);
            return parsed !== null && typeof parsed === 'object' ? candidate : false;
        } catch (_) {
            return false;
        }
    }

    function getPreservedValueAtPath(rootValue, keys) {
        let value = rootValue;
        (keys || []).forEach((key) => {
            if (value === null || value === undefined) {
                value = undefined;
                return;
            }
            if (typeof key === 'string' && key.startsWith('[') && key.endsWith(']')) {
                value = value[parseInt(key.slice(1, -1), 10)];
                return;
            }
            if (Object.prototype.hasOwnProperty.call(value, key)) {
                value = value[key];
                return;
            }
            value = value[PRESERVED_INTEGER_KEY_PREFIX + key];
        });
        return value;
    }

    function getPreservedObjectKey(value, key) {
        if (value === null || value === undefined || typeof value !== 'object') return null;
        if (Object.prototype.hasOwnProperty.call(value, key)) return key;
        const preservedKey = PRESERVED_INTEGER_KEY_PREFIX + key;
        return Object.prototype.hasOwnProperty.call(value, preservedKey) ? preservedKey : null;
    }

    function deletePreservedValueAtPath(rootValue, keys) {
        keys = Array.isArray(keys) ? keys.slice() : [];
        if (!keys.length) return false;
        const lastKey = keys.pop();
        const parent = getPreservedValueAtPath(rootValue, keys);
        if (parent === null || parent === undefined) return false;

        if (typeof lastKey === 'string' && lastKey.startsWith('[') && lastKey.endsWith(']')) {
            if (!Array.isArray(parent)) return false;
            const index = parseInt(lastKey.slice(1, -1), 10);
            if (!Number.isInteger(index) || index < 0 || index >= parent.length) return false;
            parent.splice(index, 1);
            return true;
        }

        const actualKey = getPreservedObjectKey(parent, lastKey);
        if (actualKey === null) return false;
        delete parent[actualKey];
        return true;
    }

    function reindexArrayElementNodes(elements, documentRef) {
        const nodes = Array.from(elements || []);
        nodes.forEach(function (element, index) {
            if (!element || typeof element.setAttribute !== 'function') return;
            element.setAttribute('data-array-index', String(index));

            const directComma = Array.from(element.children || []).find(function (child) {
                return String(child.className || '').split(/\s+/).includes('comma');
            });
            const shouldHaveComma = index < nodes.length - 1;
            if (shouldHaveComma && !directComma) {
                const ownerDocument = documentRef || element.ownerDocument;
                if (!ownerDocument || typeof ownerDocument.createElement !== 'function') return;
                const comma = ownerDocument.createElement('span');
                comma.className = 'comma';
                comma.textContent = ',';
                element.appendChild(comma);
            } else if (!shouldHaveComma && directComma) {
                if (typeof directComma.remove === 'function') {
                    directComma.remove();
                } else if (typeof element.removeChild === 'function') {
                    element.removeChild(directComma);
                }
            }
        });
        return nodes;
    }

    function downloadJsonBlobWithAnchor(blob, filename, environment) {
        environment = environment || {};
        const documentRef = environment.documentRef || (typeof document !== 'undefined' ? document : null);
        const urlApi = environment.urlApi || (typeof URL !== 'undefined' ? URL : null);
        if (!documentRef || !documentRef.body || !documentRef.createElement || !urlApi || !urlApi.createObjectURL) {
            return false;
        }

        const objectUrl = urlApi.createObjectURL(blob);
        const link = documentRef.createElement('a');
        link.download = filename;
        link.href = objectUrl;
        link.style.display = 'none';
        documentRef.body.appendChild(link);
        link.click();
        if (typeof link.remove === 'function') {
            link.remove();
        } else if (link.parentNode) {
            link.parentNode.removeChild(link);
        }
        if (typeof urlApi.revokeObjectURL === 'function') {
            urlApi.revokeObjectURL(objectUrl);
        }
        return true;
    }

    function shouldUsePlainJsonView(value, sourceLength, options) {
        options = options || {};
        const characterLimit = Number(options.characterLimit) || 2000000;
        const nodeLimit = Number(options.nodeLimit) || 20000;
        if (Number(sourceLength) > characterLimit) return true;

        const depthLimit = Number(options.depthLimit) || 100;
        const stack = [{ value, depth: 0 }];
        const seen = typeof WeakSet === 'function' ? new WeakSet() : null;
        let nodeCount = 0;
        while (stack.length) {
            const entry = stack.pop();
            const current = entry.value;
            if (entry.depth > depthLimit) return true;
            nodeCount += 1;
            if (nodeCount > nodeLimit) return true;
            if (!current || typeof current !== 'object' || isBigNumberLike(current)) continue;
            if (seen) {
                if (seen.has(current)) continue;
                seen.add(current);
            }
            const keys = Object.keys(current);
            nodeCount += keys.length;
            if (nodeCount > nodeLimit) return true;
            keys.forEach((key) => {
                const child = current[key];
                if (child && typeof child === 'object' && !isBigNumberLike(child)) {
                    stack.push({ value: child, depth: entry.depth + 1 });
                }
            });
        }
        return false;
    }

    function coerceDecodedJSONSource(source, decodedSource, options) {
        const parsed = parseJSONLike(decodedSource, options);
        if (!parsed) {
            return source;
        }
        const original = parseJSONLike(source, options);
        if (original) {
            // Decoded quotes/braces can form valid JSON while silently replacing
            // an object or dropping an array. Automatic decoding may change string
            // contents, but must preserve every key, array entry and typed value.
            const pending = [[original.value, parsed.value]];
            while (pending.length) {
                const [before, after] = pending.pop();
                if (typeof before === 'string' && typeof after === 'string') {
                    if (before === after) continue;
                    // A string may decode only its own contents. Otherwise encoded
                    // delimiters can overwrite a sibling without changing the shape.
                    try {
                        if (decodeURIComponent(before) === after) continue;
                    } catch (_) { /* Ambiguous/invalid escapes retain the original JSON. */ }
                    return source;
                }
                if (before === after) continue;
                if (!before || !after || typeof before !== 'object' || typeof after !== 'object' ||
                    Array.isArray(before) !== Array.isArray(after)) {
                    return source;
                }
                const keys = Object.keys(before);
                if (keys.length !== Object.keys(after).length) return source;
                for (const key of keys) {
                    if (!Object.prototype.hasOwnProperty.call(after, key)) return source;
                    pending.push([before[key], after[key]]);
                }
            }
        }
        return parsed.normalizedSource;
    }

    function isYAMLResource(url, contentType) {
        const type = String(contentType || '').toLowerCase();
        if (type.includes('yaml') || type.includes('yml')) {
            return true;
        }

        let pathname = '';
        try {
            pathname = new URL(String(url || ''), 'https://fehelper.local').pathname;
        } catch (_) {
            pathname = String(url || '').split(/[?#]/)[0];
        }

        return /\.ya?ml$/i.test(pathname);
    }

    function isMarkdownResource(url, contentType) {
        const type = String(contentType || '').toLowerCase();
        if (type.includes('markdown') || type.includes('x-markdown')) {
            return true;
        }

        let pathname = '';
        try {
            pathname = new URL(String(url || ''), 'https://fehelper.local').pathname;
        } catch (_) {
            pathname = String(url || '').split(/[?#]/)[0];
        }

        return /\.(md|markdown|mdown|mkd|mkdn)$/i.test(pathname);
    }

    return {
        isBigNumberLike,
        isYAMLResource,
        isMarkdownResource,
        getStandaloneHTMLJSONCandidate,
        getPreservedValueAtPath,
        deletePreservedValueAtPath,
        reindexArrayElementNodes,
        downloadJsonBlobWithAnchor,
        markIntegerIndexKeys,
        normalizePreservedKey,
        normalizePreservedJsonPointer,
        parseWithBigInt,
        normalizeLooseJSONSource,
        deepParseJSONStrings,
        unpackTopLevelEscapedJSON,
        safeStringify,
        parseJSONLike,
        shouldUsePlainJsonView,
        coerceDecodedJSONSource,
    };
});
