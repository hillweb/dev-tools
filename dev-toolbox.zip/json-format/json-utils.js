(function () {

    /**
     * JSON 核心纯函数模块 —— 可被 Vitest 直接测试，也供 format-lib / json-worker 引用
     */

    const PRESERVED_INTEGER_KEY_PREFIX = '__FH_PRESERVE_INTEGER_KEY__';

    // ─── HTML 转义 ──────────────────────────────────────────────
    function htmlspecialchars(str) {
        return str
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    // ─── URL 检测 ───────────────────────────────────────────────
    function isUrl(str) {
        if (typeof str !== 'string') return false;
        return /^(https?:\/\/|ftp:\/\/)[^\s<>"'\\]+$/i.test(str);
    }

    // ─── BigNumber duck-typing ──────────────────────────────────
    function isBigNumberLike(value) {
        return (
            value !== null &&
            value !== undefined &&
            typeof value === 'object' &&
            typeof value.s === 'number' &&
            typeof value.e === 'number' &&
            Array.isArray(value.c)
        );
    }

    // ─── 类型判断 ───────────────────────────────────────────────
    function getType(value) {
        if (value === null) return 'null';
        if (value === undefined) return 'undefined';
        if (typeof value === 'bigint') return 'bigint';
        if (typeof value === 'object') {
            if (isBigNumberLike(value)) return 'bigint';
            if (Array.isArray(value)) return 'array';
            return 'object';
        }
        return typeof value;
    }

    // ─── BigNumber → 字符串 ─────────────────────────────────────
    function rebuildBigNumberFromParts(value) {
        const sign = value.s < 0 ? '-' : '';
        const CHUNK_SIZE = 14;
        let digits = '';

        for (let i = 0; i < value.c.length; i++) {
            let chunkStr = Math.abs(value.c[i]).toString();
            if (i > 0) {
                chunkStr = chunkStr.padStart(CHUNK_SIZE, '0');
            }
            digits += chunkStr;
        }

        digits = digits.replace(/^0+/, '') || '0';
        const decimalIndex = value.e + 1;

        if (decimalIndex <= 0) {
            const zeros = '0'.repeat(Math.abs(decimalIndex));
            let fraction = zeros + digits;
            fraction = fraction.replace(/0+$/, '');
            if (!fraction) return sign + '0';
            return sign + '0.' + fraction;
        }
        if (decimalIndex >= digits.length) {
            return sign + digits + '0'.repeat(decimalIndex - digits.length);
        }

        const intPart = digits.slice(0, decimalIndex);
        let fracPart = digits.slice(decimalIndex).replace(/0+$/, '');
        if (!fracPart) return sign + intPart;
        return sign + intPart + '.' + fracPart;
    }

    function getBigNumberDisplayString(value) {
        if (typeof value === 'bigint') return value.toString();
        if (!isBigNumberLike(value)) return String(value);

        if (typeof value.toString === 'function' && value.toString !== Object.prototype.toString) {
            try {
                const result = value.toString();
                if (typeof result === 'string' && result !== '[object Object]') {
                    return result;
                }
            } catch (_) { }
        }
        return rebuildBigNumberFromParts(value);
    }

    function isInsideQuotedSegment(text, offset) {
        let quote = '';
        let escaped = false;

        for (let i = 0; i < offset; i++) {
            const char = text[i];
            if (escaped) {
                escaped = false;
                continue;
            }
            if (char === '\\') {
                escaped = true;
                continue;
            }
            if (quote) {
                if (char === quote) quote = '';
                continue;
            }
            if (char === '"' || char === "'") {
                quote = char;
            }
        }

        return !!quote;
    }

    function replaceOutsideQuotedSegments(text, regex, replacer) {
        return text.replace(regex, function () {
            const args = Array.prototype.slice.call(arguments);
            const offset = args[args.length - 2];
            if (isInsideQuotedSegment(text, offset)) {
                return args[0];
            }
            return replacer.apply(null, args);
        });
    }

    /**
     * 去除 JSONC（JSON with Comments）中的行注释与块注释。
     * 行注释以两个斜杠开头，块注释由斜杠星号开始、星号斜杠结束。
     * 字符串内部的斜杠不会被处理，http:// 这类 URL 不会被破坏。
     */
    function stripJsonComments(text) {
        if (typeof text !== 'string' || text.indexOf('/') === -1) {
            return text;
        }

        let result = '';
        let inString = false;
        let escaped = false;

        for (let i = 0; i < text.length; i++) {
            const char = text[i];

            if (inString) {
                result += char;
                if (escaped) {
                    escaped = false;
                } else if (char === '\\') {
                    escaped = true;
                } else if (char === '"') {
                    inString = false;
                }
                continue;
            }

            if (char === '"') {
                inString = true;
                result += char;
                continue;
            }

            if (char === '/') {
                const next = text.charAt(i + 1);
                if (next === '/') {
                    i += 1;
                    while (i + 1 < text.length && text.charAt(i + 1) !== '\n' && text.charAt(i + 1) !== '\r') {
                        i += 1;
                    }
                    continue;
                }
                if (next === '*') {
                    i += 2;
                    while (i < text.length && !(text.charAt(i) === '*' && text.charAt(i + 1) === '/')) {
                        i += 1;
                    }
                    i += 1;
                    continue;
                }
            }

            result += char;
        }

        return result;
    }

    function normalizeLooseJSONSource(text) {
        let fixed = String(text).trim();

        fixed = replaceOutsideQuotedSegments(fixed, /([\{,]\s*)'([^'\\]*?)'(\s*:)/g, function (match, prefix, key, suffix) {
            return prefix + '"' + key + '"' + suffix;
        });
        fixed = replaceOutsideQuotedSegments(fixed, /([\{,]\s*)(\w+)(\s*:)/g, function (match, prefix, key, suffix) {
            return prefix + '"' + key + '"' + suffix;
        });
        fixed = replaceOutsideQuotedSegments(fixed, /(:\s*)'([^'\\]*?)'/g, function (match, prefix, value) {
            return prefix + '"' + value + '"';
        });

        return fixed;
    }

    function isIntegerIndexKey(key) {
        if (typeof key !== 'string' || !/^(0|[1-9]\d*)$/.test(key)) return false;
        const value = Number(key);
        return Number.isSafeInteger(value) && value >= 0 && value < 4294967295 && String(value) === key;
    }

    function markIntegerIndexKeys(source) {
        source = String(source || '');
        let result = '';
        let i = 0;

        while (i < source.length) {
            if (source[i] !== '"') {
                result += source[i++];
                continue;
            }

            const start = i;
            i++;
            let escaped = false;
            while (i < source.length) {
                const char = source[i++];
                if (escaped) {
                    escaped = false;
                    continue;
                }
                if (char === '\\') {
                    escaped = true;
                    continue;
                }
                if (char === '"') {
                    break;
                }
            }

            const rawKey = source.slice(start, i);
            let j = i;
            while (j < source.length && /\s/.test(source[j])) j++;

            if (source[j] === ':') {
                try {
                    const key = JSON.parse(rawKey);
                    if (isIntegerIndexKey(key)) {
                        result += JSON.stringify(PRESERVED_INTEGER_KEY_PREFIX + key);
                        continue;
                    }
                } catch (_) { }
            }

            result += rawKey;
        }

        return result;
    }

    function normalizePreservedKey(key) {
        if (typeof key === 'string' && key.indexOf(PRESERVED_INTEGER_KEY_PREFIX) === 0) {
            return key.slice(PRESERVED_INTEGER_KEY_PREFIX.length);
        }
        return key;
    }

    function getPreservedProperty(value, key) {
        if (value === null || value === undefined || typeof value !== 'object') {
            return { found: false, key, value: undefined };
        }
        if (Object.prototype.hasOwnProperty.call(value, key)) {
            return { found: true, key, value: value[key] };
        }
        const preservedKey = PRESERVED_INTEGER_KEY_PREFIX + key;
        if (Object.prototype.hasOwnProperty.call(value, preservedKey)) {
            return { found: true, key: preservedKey, value: value[preservedKey] };
        }
        return { found: false, key, value: undefined };
    }

    function normalizePreservedJsonPointer(path) {
        if (typeof path !== 'string') return path;

        return path.split('/').map((segment, index) => {
            if (index === 0) return segment;
            if (segment.indexOf(PRESERVED_INTEGER_KEY_PREFIX) === 0) {
                return segment.slice(PRESERVED_INTEGER_KEY_PREFIX.length);
            }
            return segment;
        }).join('/');
    }

    // ─── BigInt 安全解析（统一实现，替代 format-lib 和 json-worker 各自的版本）──
    function parseWithBigInt(text) {
        let fixed = normalizeLooseJSONSource(text);
        const ordered = markIntegerIndexKeys(fixed);

        // 3) 标记 16 位及以上的整数，确保不在字符串内部
        const marked = ordered.replace(
            /([:,\[]\s*)(-?\d{16,})(\s*)(?=[,\]\}])/g,
            function (match, prefix, number, spaces, offset) {
                if (isInsideQuotedSegment(ordered, offset)) return match;
                return prefix + '"__BigInt__' + number + '"' + spaces;
            },
        );

        return JSON.parse(marked, function (_key, value) {
            if (typeof value === 'string' && value.startsWith('__BigInt__')) {
                try {
                    return BigInt(value.slice(10));
                } catch (_) {
                    return value.slice(10);
                }
            }
            return value;
        });
    }

    // ─── 深度解包嵌套 JSON 字符串 ──────────────────────────────
    function deepParseJSONStrings(obj) {
        if (Array.isArray(obj)) {
            return obj.map((item) => {
                if (typeof item === 'string' && item.trim()) {
                    try {
                        const parsed = JSON.parse(item);
                        if (_isDeepParsable(parsed)) {
                            return deepParseJSONStrings(parsed);
                        }
                    } catch (_) { }
                }
                return deepParseJSONStrings(item);
            });
        }
        if (typeof obj === 'object' && obj !== null) {
            const newObj = {};
            for (const key of Object.keys(obj)) {
                const val = obj[key];
                if (typeof val === 'string' && val.trim()) {
                    try {
                        const parsed = JSON.parse(val);
                        if (_isDeepParsable(parsed)) {
                            newObj[key] = deepParseJSONStrings(parsed);
                            continue;
                        }
                    } catch (_) { }
                }
                newObj[key] = deepParseJSONStrings(val);
            }
            return newObj;
        }
        return obj;
    }

    function unpackTopLevelEscapedJSON(value) {
        if (typeof value !== 'string' || !value.trim()) return value;

        try {
            const parsed = parseWithBigInt(value);
            if (_isDeepParsable(parsed)) {
                return deepParseJSONStrings(parsed);
            }
        } catch (_) { }

        return value;
    }

    function _isDeepParsable(parsed) {
        if (typeof parsed !== 'object' || parsed === null) return false;
        if (!Array.isArray(parsed) && Object.prototype.toString.call(parsed) !== '[object Object]') return false;
        // 排除 BigNumber duck-type {s, e, c}
        if (isBigNumberLike(parsed) && Object.keys(parsed).length === 3) return false;
        return true;
    }

    // ─── Unicode 编解码 ─────────────────────────────────────────
    function uniEncode(str) {
        return escape(str)
            .replace(/%u/gi, '\\u')
            .replace(/%7b/gi, '{')
            .replace(/%7d/gi, '}')
            .replace(/%3a/gi, ':')
            .replace(/%2c/gi, ',')
            .replace(/%27/gi, "'")
            .replace(/%22/gi, '"')
            .replace(/%5b/gi, '[')
            .replace(/%5d/gi, ']')
            .replace(/%3D/gi, '=')
            .replace(/%08/gi, '\b')
            .replace(/%0D/gi, '\r')
            .replace(/%0C/gi, '\f')
            .replace(/%09/gi, '\t')
            .replace(/%20/gi, ' ')
            .replace(/%0A/gi, '\n')
            .replace(/%3E/gi, '>')
            .replace(/%3C/gi, '<')
            .replace(/%3F/gi, '?');
    }

    function uniDecode(text) {
        text = text.replace(/(\\)?\\u/gi, '%u').replace('%u0025', '%25');
        text = unescape(text.toString().replace(/%2B/g, '+'));
        const matches = text.match(/(%u00([0-9A-F]{2}))/gi);
        if (matches) {
            for (const m of matches) {
                const code = m.substring(1, 3);
                const x = Number('0x' + code);
                if (x >= 128) text = text.replace(m, code);
            }
        }
        return unescape(text.toString().replace(/%2B/g, '+'));
    }

    // ─── 安全的 safeStringify（保留 BigInt 精度）──────────────
    function safeStringify(obj, space) {
        const tagged = JSON.stringify(
            obj,
            function (_key, value) {
                if (typeof value === 'bigint') {
                    return `__FH_BIGINT__${value.toString()}`;
                }
                if (typeof value === 'number' && value.toString().includes('e')) {
                    return `__FH_NUMSTR__${value.toLocaleString('fullwide', { useGrouping: false })}`;
                }
                if (isBigNumberLike(value)) {
                    return `__FH_BIGNUM__${getBigNumberDisplayString(value)}`;
                }
                return value;
            },
            space,
        );
        return tagged
            .replace(/"__FH_BIGINT__(-?\d+)"/g, '$1')
            .replace(/"__FH_NUMSTR__(-?\d+)"/g, '$1')
            .replace(/"__FH_BIGNUM__(-?\d+(?:\.\d+)?)"/g, '$1')
            .replace(new RegExp('"' + PRESERVED_INTEGER_KEY_PREFIX + '(\\d+)":', 'g'), '"$1":');
    }

    function sanitizeJsonDownloadFilename(note, fallbackPrefix = 'FeHelper', maxLength = 64) {
        const fallback = fallbackPrefix || 'FeHelper';
        let value = String(note || '')
            .trim()
            .replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_')
            .replace(/\s+/g, '_')
            .replace(/_{2,}/g, '_')
            .replace(/^[._\-\s]+|[._\-\s]+$/g, '');

        if (!value) {
            value = fallback;
        }

        const limit = Math.max(12, Number(maxLength) || 64);
        if (value.length > limit) {
            value = value.slice(0, limit).replace(/[._\-\s]+$/g, '');
        }

        return value || fallback;
    }

    function mergeSchemaType(left, right) {
        const types = [];
        const add = (type) => {
            if (Array.isArray(type)) {
                type.forEach(add);
                return;
            }
            if (type && !types.includes(type)) {
                types.push(type);
            }
        };
        add(left);
        add(right);
        return types.length === 1 ? types[0] : types;
    }

    function normalizeMergedSchema(schema) {
        if (!schema) return {};
        if (schema.type === 'integer' || schema.type === 'number' || schema.type === 'string' || schema.type === 'boolean' || schema.type === 'null') {
            return schema;
        }
        return schema;
    }

    function mergeJsonSchemas(a, b) {
        if (!a) return b;
        if (!b) return a;

        if (a.type === 'object' && b.type === 'object') {
            const properties = {};
            const keys = Array.from(new Set(Object.keys(a.properties || {}).concat(Object.keys(b.properties || {})))).sort();
            keys.forEach((key) => {
                properties[key] = mergeJsonSchemas(a.properties && a.properties[key], b.properties && b.properties[key]);
            });
            const aRequired = new Set(a.required || []);
            const bRequired = new Set(b.required || []);
            const required = keys.filter((key) => aRequired.has(key) && bRequired.has(key));
            const result = {
                type: 'object',
                properties,
                additionalProperties: false,
            };
            if (required.length) {
                result.required = required;
            }
            return result;
        }

        if (a.type === 'array' && b.type === 'array') {
            return {
                type: 'array',
                items: mergeJsonSchemas(a.items, b.items) || {},
            };
        }

        return normalizeMergedSchema({
            type: mergeSchemaType(a.type, b.type),
        });
    }

    function inferJsonSchema(value) {
        if (value === null) {
            return { type: 'null' };
        }
        if (Array.isArray(value)) {
            return {
                type: 'array',
                items: value.reduce((schema, item) => mergeJsonSchemas(schema, inferJsonSchema(item)), null) || {},
            };
        }
        if (typeof value === 'object') {
            if (isBigNumberLike(value)) {
                return { type: 'number' };
            }
            const keys = Object.keys(value).sort();
            const properties = {};
            keys.forEach((key) => {
                properties[normalizePreservedKey(key)] = inferJsonSchema(value[key]);
            });
            const result = {
                type: 'object',
                properties,
                additionalProperties: false,
            };
            if (keys.length) {
                result.required = keys.map(normalizePreservedKey);
            }
            return result;
        }
        if (typeof value === 'bigint') {
            return { type: 'integer' };
        }
        if (typeof value === 'number') {
            return { type: Number.isInteger(value) ? 'integer' : 'number' };
        }
        if (typeof value === 'boolean') {
            return { type: 'boolean' };
        }
        return { type: 'string' };
    }

    function buildJsonSchema(value) {
        return {
            $schema: 'https://json-schema.org/draft/2020-12/schema',
            title: 'RootSchema',
            ...inferJsonSchema(value),
        };
    }

    // ─── 日期格式化（替代 Date.prototype.format 的纯函数版本）──
    function formatDate(date, pattern) {
        const pad = (src, len) => {
            const neg = src < 0;
            let s = String(Math.abs(src));
            while (s.length < len) s = '0' + s;
            return (neg ? '-' : '') + s;
        };
        if (typeof pattern !== 'string') return date.toString();

        const y = date.getFullYear();
        const M = date.getMonth() + 1;
        const d = date.getDate();
        const H = date.getHours();
        const m = date.getMinutes();
        const s = date.getSeconds();
        const S = date.getMilliseconds();

        return pattern
            .replace(/yyyy/g, pad(y, 4))
            .replace(/yy/g, pad(parseInt(y.toString().slice(2), 10), 2))
            .replace(/MM/g, pad(M, 2))
            .replace(/M/g, M)
            .replace(/dd/g, pad(d, 2))
            .replace(/d/g, d)
            .replace(/HH/g, pad(H, 2))
            .replace(/H/g, H)
            .replace(/hh/g, pad(H % 12, 2))
            .replace(/h/g, H % 12)
            .replace(/mm/g, pad(m, 2))
            .replace(/ss/g, pad(s, 2))
            .replace(/SSS/g, pad(S, 3))
            .replace(/S/g, S);
    }

    // ─── 字符串字节数（替代 String.prototype.getBytes 的纯函数版本）──
    function getStringBytes(str) {
        const stream = str.replace(/\n/g, 'xx').replace(/\t/g, 'x');
        const escaped = encodeURIComponent(stream);
        return escaped.replace(/%[A-Z0-9][A-Z0-9]/g, 'x').length;
    }

    // ─── toast 安全版（XSS 防护）────────────────────────────────
    function createSafeToastHTML(content) {
        const safe = htmlspecialchars(content);
        return (
            '<div id="fehelper_alertmsg" style="position:fixed;top:5px;right:5px;z-index:1000000">' +
            '<p style="background:#000;display:inline-block;color:#fff;text-align:center;' +
            'padding:10px 10px;margin:0 auto;font-size:14px;border-radius:4px;">' +
            safe +
            '</p></div>'
        );
    }

    window.FHJsonUtils = {
        htmlspecialchars,
        isUrl,
        isBigNumberLike,
        getType,
        rebuildBigNumberFromParts,
        getBigNumberDisplayString,
        isIntegerIndexKey,
        markIntegerIndexKeys,
        normalizePreservedKey,
        getPreservedProperty,
        normalizePreservedJsonPointer,
        parseWithBigInt,
        deepParseJSONStrings,
        unpackTopLevelEscapedJSON,
        uniEncode,
        uniDecode,
        safeStringify,
        sanitizeJsonDownloadFilename,
        stripJsonComments,
        buildJsonSchema,
        formatDate,
        getStringBytes,
        createSafeToastHTML
    };

})();
