// 直接加载官方完整版 SVGO 浏览器模块
import { optimize } from './svgo.browser.js';

const statusEl = document.getElementById('engineStatus');
statusEl.textContent = 'SVGO v3.3.2 引擎就绪';
statusEl.classList.add('ready');

const inputCode = document.getElementById('inputCode');
const outputCode = document.getElementById('outputCode');
const previewBox = document.getElementById('previewBox');
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');

let currentTab = 'code';
let uploadedFiles = [];

function runSvgo(rawSvg) {
    if (!rawSvg || !rawSvg.trim()) return '';
    const floatPrecision = Number(document.getElementById('optPrecision').value);
    const multipass = document.getElementById('optMultipass').checked;
    const mergePaths = document.getElementById('optMergePaths').checked;
    const removeFill = document.getElementById('optRemoveFill').checked;

    const plugins = [
        {
            name: 'preset-default',
            params: {
                overrides: {
                    // 保留 viewBox 防止缩放失真
                    removeViewBox: false,
                    cleanupNumericValues: { floatPrecision },
                    convertPathData: { floatPrecision },
                    convertTransform: { floatPrecision },
                    mergePaths: mergePaths ? { force: true, floatPrecision } : false,
                    inlineStyles: { onlyMatchedOnce: false },
                }
            }
        },
        // 将 width/height 转为 viewBox 进一步精简
        'removeDimensions',
        'convertStyleToAttrs',
    ];

    if (removeFill) {
        plugins.push({
            name: 'removeAttrs',
            params: { attrs: 'fill' }
        });
    }

    try {
        const result = optimize(rawSvg, { multipass, plugins });
        return result.data;
    } catch (err) {
        return `/* SVG 解析失败: ${err.message} */`;
    }
}

function buildSprites(files) {
    const symbols = files.map((file, idx) => {
        const optimized = runSvgo(file.content);
        const doc = new DOMParser().parseFromString(optimized, 'image/svg+xml');
        const svg = doc.querySelector('svg');
        if (!svg) return '';
        const id = file.name.replace(/\.svg$/i, '') || `icon-${idx}`;
        const viewBox = svg.getAttribute('viewBox') || '0 0 24 24';
        return `<symbol id="${id}" viewBox="${viewBox}">${svg.innerHTML}</symbol>`;
    }).join('');
    return `<svg xmlns="http://www.w3.org/2000/svg" style="display:none">${symbols}</svg>`;
}

function svgToCssUrl(svg) {
    const encoded = svg
        .replace(/"/g, "'")
        .replace(/%/g, '%25')
        .replace(/#/g, '%23')
        .replace(/{/g, '%7B')
        .replace(/}/g, '%7D')
        .replace(/</g, '%3C')
        .replace(/>/g, '%3E');
    return `url("data:image/svg+xml,${encoded}")`;
}

function process() {
    const isSprite = document.getElementById('optMergeSprite').checked && uploadedFiles.length > 0;
    const raw = inputCode.value;
    const compressed = isSprite ? buildSprites(uploadedFiles) : runSvgo(raw);

    const origBytes = new Blob([raw]).size;
    const compBytes = new Blob([compressed]).size;
    const saved = origBytes - compBytes;
    const ratio = origBytes > 0 ? ((saved / origBytes) * 100).toFixed(1) : 0;

    //字节转为K字节
    const origBytesK = (origBytes / 1024).toFixed(1);
    const compBytesK = (compBytes / 1024).toFixed(1);
    const savedK = (saved / 1024).toFixed(1);

    document.getElementById('origSize').textContent = `原始大小: ${origBytesK} KB`;
    document.getElementById('compSize').innerHTML = origBytes > 0
        ? `压缩后: ${compBytesK} KB <span class="highlight">(节省 ${savedK} KB / ${ratio}%)</span>`
        : `压缩后: 0 B`;

    if (currentTab === 'preview') {
        outputCode.classList.add('hidden');
        previewBox.classList.remove('hidden');
        previewBox.innerHTML = compressed;
    } else {
        previewBox.classList.add('hidden');
        outputCode.classList.remove('hidden');
        if (currentTab === 'code') {
            outputCode.value = compressed;
        } else if (currentTab === 'base64') {
            outputCode.value = compressed ? `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(compressed)))}` : '';
        } else if (currentTab === 'css') {
            outputCode.value = compressed ? svgToCssUrl(compressed) : '';
        }
    }
}

// 事件监听
inputCode.addEventListener('input', () => { uploadedFiles = []; process(); });
document.querySelectorAll('.options input, .options select').forEach(el => el.addEventListener('change', process));

document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentTab = btn.dataset.tab;
        process();
    });
});

dropZone.addEventListener('click', () => fileInput.click());
dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('dragover'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    handleFiles(e.dataTransfer.files);
});
fileInput.addEventListener('change', e => handleFiles(e.target.files));

async function handleFiles(fileList) {
    const svgFiles = Array.from(fileList).filter(f => f.name.endsWith('.svg'));
    if (!svgFiles.length) return;
    uploadedFiles = await Promise.all(svgFiles.map(async f => ({
        name: f.name,
        content: await f.text()
    })));
    inputCode.value = uploadedFiles.map(f => f.content).join('\n\n');
    if (uploadedFiles.length > 1) {
        document.getElementById('optMergeSprite').checked = true;
    }
    process();
}

document.getElementById('copyBtn').addEventListener('click', () => {
    navigator.clipboard.writeText(outputCode.value);
    const btn = document.getElementById('copyBtn');
    btn.textContent = '已复制 ✓';
    setTimeout(() => btn.textContent = '复制结果', 1500);
});

document.getElementById('downloadBtn').addEventListener('click', () => {
    const content = currentTab === 'code' ? outputCode.value : runSvgo(inputCode.value);
    if (!content) return;
    const blob = new Blob([content], { type: 'image/svg+xml' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'optimized.svg';
    a.click();
});
//svg转png ； convertToPngBtn
document.getElementById('convertToPngBtn').addEventListener('click', () => {
    const content = currentTab === 'code' ? outputCode.value : runSvgo(inputCode.value);
    if (!content) return;
    exportSvgToRaster(content, 'png', 256);
});
//SVG转ICO；convertToIcoBtn
document.getElementById('convertToIcoBtn').addEventListener('click', () => {
    const content = currentTab === 'code' ? outputCode.value : runSvgo(inputCode.value);
    if (!content) return;
    exportSvgToRaster(content, 'ico', 256);
});

/**
 * 将 SVG 字符串转换为 PNG / JPG / ICO 并触发下载
 * @param {string} svgString - 原始或经过 SVGO 压缩的 SVG 代码
 * @param {'png'|'jpeg'|'ico'} format - 目标格式
 * @param {number} size - 目标尺寸（宽高，如 32, 64, 256, 512）
 */
async function exportSvgToRaster(svgString, format = 'png', size = 256) {
  // 1. 确保 SVG 根节点带有明确的宽高，否则部分浏览器 Canvas 绘制时可能尺寸异常
  const parser = new DOMParser();
  const doc = parser.parseFromString(svgString, 'image/svg+xml');
  const svgEl = doc.querySelector('svg');
  if (!svgEl) throw new Error('无效的 SVG 代码');
  
  svgEl.setAttribute('width', size);
  svgEl.setAttribute('height', size);
  const finalSvg = new XMLSerializer().serializeToString(svgEl);

  // 2. 创建 Blob 与 Image
  const svgBlob = new Blob([finalSvg], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(svgBlob);

  const img = new Image();
  await new Promise((resolve, reject) => {
    img.onload = resolve;
    img.onerror = reject;
    img.src = url;
  });

  // 3. 绘制到 Canvas
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');

  // JPG 不支持透明，必须填充白色背景
  if (format === 'jpeg') {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, size, size);
  }

  ctx.drawImage(img, 0, 0, size, size);
  URL.revokeObjectURL(url);

  // 4. 导出与下载
  if (format === 'ico') {
    // 限制 ICO 单个图像最大尺寸为 256x256（ICO 规范限制，256 在头信息中记为 0）
    const icoBlob = await canvasToIcoBlob(canvas);
    triggerDownload(icoBlob, `icon-${size}x${size}.ico`);
  } else {
    const mimeType = format === 'jpeg' ? 'image/jpeg' : 'image/png';
    canvas.toBlob((blob) => {
      triggerDownload(blob, `image-${size}x${size}.${format === 'jpeg' ? 'jpg' : 'png'}`);
    }, mimeType, 0.92);
  }
}

/**
 * 将 Canvas 封装为标准 Windows ICO 格式 (内嵌 PNG 帧)
 */
async function canvasToIcoBlob(canvas) {
  const pngBlob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
  const pngBuffer = await pngBlob.arrayBuffer();
  const pngBytes = new Uint8Array(pngBuffer);

  // 6 字节 ICONDIR + 16 字节 ICONDIRENTRY = 22 字节文件头
  const header = new ArrayBuffer(22);
  const view = new DataView(header);

  // ICONDIR
  view.setUint16(0, 0, true); // 保留位，必须为 0
  view.setUint16(2, 1, true); // 类型：1 代表 ICO，2 代表 CUR
  view.setUint16(4, 1, true); // 包含的图像数量：1 张

  // ICONDIRENTRY
  const width = canvas.width >= 256 ? 0 : canvas.width;
  const height = canvas.height >= 256 ? 0 : canvas.height;
  view.setUint8(6, width);              // 宽度 (0 表示 256px)
  view.setUint8(7, height);             // 高度 (0 表示 256px)
  view.setUint8(8, 0);                  // 调色板颜色数 (PNG 填 0)
  view.setUint8(9, 0);                  // 保留位
  view.setUint16(10, 1, true);          // 色彩平面数
  view.setUint16(12, 32, true);         // 色深 (32位 RGBA)
  view.setUint32(14, pngBytes.length, true); // 图像数据大小（字节）
  view.setUint32(18, 22, true);         // 图像数据起始偏移量

  return new Blob([header, pngBytes], { type: 'image/x-icon' });
}

function triggerDownload(blob, filename) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}